package com.dojan.MyGame.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;

import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.dojan.MyGame.io.Entradas;
import elementos.Imagen;
import elementos.Texto;
import utiles.Recursos;
import utiles.Render;

public class PantallaMenu implement Screen{

        Imagen fondo;
        SpriteBatch b;
//        Texto o1, o2, o3, o4;
        Texto opciones[] = new Texto[4];
        String textos[] = {" Jugar", "Online", "Opciones", "Salir"};

        int opc=1;

        public float tiempo=0;

        Entradas entradas = new Entradas(this);


        @Override
        public void show(){
            fondo = new Imagen(Recursos.FONDOMENU);
            fondo.setSize(1280, 768);
            b = Render.batch; //agregar render

            Gdx.input.setInputProcessor(entradas);
            int a=0;
            for(int i=0;i<opciones.length; i++){

                opciones[i]= new Texto(new Texto(Recursos.FUENTEMENU, 80, Color.WHITE));
                opciones[i].setTexto(textos[i]);
                opciones[i].setPosition(200, 200-a);
                a=a+50;
            }
   //         o1 = new Texto(Recursos.FUENTEMENU, 80, Color.WHITE);
     //       o1.setTexto("Jugar");
    //        o1.setPosition(200, 200);

      //      o2 = new Texto(Recursos.FUENTEMENU, 80, Color.WHITE);
        //    o2.setTexto("online");
          //  o2.setPosition(200, 150);

       //     o3 = new Texto(Recursos.FUENTEMENU, 80, Color.WHITE);
      //      o3.setTexto("opciones");
        //    o3.setPosition(200, 100);

        //    o4 = new Texto(Recursos.FUENTEMENU, 80, Color.WHITE);
         //   o4.setTexto("salir");
          //  o4.setPosition(200, 50);

        }
        @Override
        public void render(float delta){
            b.begin();
            fondo.dibujar();
            for (int i=0; i=<opciones.length; i++){
                opciones[i].dibujar();
            }
//            o1.dibujar();
//            o2.dibujar();
//            o3.dibujar();
//            o4.dibujar();
            b.end();

            tiempo+=delta;

            if(entradas.isAbajo()){
                if(tiempo>0,09f) {
                    tiempo=0;
                    opc++;
                    if (opc > 4) {
                        opc = 1;
                    }
                }
            }
            if(entradas.isArriba()){
                if(tiempo>0,09f) {
                    tiempo=0;
                    opc--;
                    if (opc < 1) {
                        opc = 4;
                    }
                }
            }
            for( int i=0; i<i <opciones.length; i++){
                if(i==(opc-1)){
                    opciones[i].setColor(Color.RED);
                }else{
                    opciones[i].setColor(Color.WHITE);
                }
            }

            if(entradas.isEnter()){
                if (opc==1){
                    //llamar al juego
                }
            }
            if(entradas.isEnter()){
                if (opc==2){
                    //llamar al juego online
                }
                if(entradas.isEnter()){
                    if (opc==3){
                        //llamar a opcines
                    }
                    if(entradas.isEnter()){
                        if (opc==4){
                            //llamar a alt f4
                        }
//            if(opc==1){
//                o2.setColor(Color.WHITE);
//                o4.setColor(Color.WHITE);
//                o1.setColor(Color.RED);
                //    }
            //else if(opc==2){
                //o1.setColor(Color.WHITE);
                //o3.setColor(Color.WHITE);
                //o2.setColor(Color.RED);
                //           }
//            else if(opc==3){
//                o2.setColor(Color.WHITE);
//                o4.setColor(Color.WHITE);
//                o3.setColor(Color.RED);
//            }
//            else if(opc==4){
//                o1.setColor(Color.WHITE);
//                o3.setColor(Color.WHITE);
//                o4.setColor(Color.RED);
//            }
            //           System.out.println(tiempo);
        }
        @Override
        public void resize (int width, int height ){

        }
    }
