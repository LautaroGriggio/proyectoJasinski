package com.dojam.mygame;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import utiles.Render;

public class MyGame extends Game {
    public SpriteBatch batch;

    @Override
    public void create() {
        batch = new SpriteBatch();
        Render.batch = batch;
        Render.app = this;

        // arrancamos mostrando el menú
        setScreen(new PantallaMenu(this));
    }

    @Override
    public void dispose() {
        batch.dispose();
    }
}
