package com.dojam.mygame;

public class Recursos {
    // Acá podés declarar rutas de imágenes, fuentes, sonidos, etc.
    public static final String FONDO_MENU = "fondos/fondoJuego.png";
    public static final String FUENTE = "fuentes/sewer.ttf";
}
