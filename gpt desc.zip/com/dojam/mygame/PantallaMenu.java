package com.dojam.mygame;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import utiles.Render;

public class PantallaMenu implements Screen {
    private final MyGame game;
    private Texture fondo;
    private BitmapFont fuente;

    public PantallaMenu(MyGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        fondo = new Texture("fondos/fondoJuego.png");
        fuente = new BitmapFont(); // usa la fuente por defecto
    }

    @Override
    public void render(float delta) {
        Render.limpiarPantalla(0, 0, 0); // limpiar con negro

        Render.batch.begin();
        Render.batch.draw(fondo, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        fuente.draw(Render.batch, "MENU PRINCIPAL", 50, 100);
        Render.batch.end();
    }

    @Override public void resize(int width, int height) {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
    @Override
    public void dispose() {
        fondo.dispose();
        fuente.dispose();
    }
}
