package utiles;

public class Recursos {
    public static final String FONDOMENU = "fondos/fondoJuego.png";
    public static final String FUENTEMENU = "fuentes/sewer.ttf";
}
